# B00merang-Blackout
Darkness falls upon the Linux desktop with this totally out-of-the-80's CLI-like GTK theme
