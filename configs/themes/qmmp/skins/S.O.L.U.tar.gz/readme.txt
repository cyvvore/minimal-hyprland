Signal Outpuit Line Up (or S.O.L.U.) by ru5tyshark

A clean simple skin, just how I like it and maybe you too?!
Only tested on Audacious, Qmmp & Winamp (running through wine which doesn't work perfectly but is usable except for the mini-browser looking uglier than sin), 
I mostly use it in Qmmp double sized so YMMV. A windoze version is there in .wsz format (which is just a renamed zip file) if anyone cares.
Thanks to Gimp, Kate and Winamp Regione Txt generator (which is included).
Hopefully final version but there's always something I'm not happy with but it's functional as is, so i hope you like it.

Enjoy ('-' )
